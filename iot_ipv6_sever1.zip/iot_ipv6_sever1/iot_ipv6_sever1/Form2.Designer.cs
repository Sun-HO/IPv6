﻿namespace iot_ipv6_sever1
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.PB_xiaodeng = new System.Windows.Forms.PictureBox();
            this.BTN_red = new System.Windows.Forms.Button();
            this.BTN_green = new System.Windows.Forms.Button();
            this.BTN_blue = new System.Windows.Forms.Button();
            this.LB_red = new System.Windows.Forms.Label();
            this.LB_green = new System.Windows.Forms.Label();
            this.LB_blue = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.PB_xiaodeng)).BeginInit();
            this.SuspendLayout();
            // 
            // PB_xiaodeng
            // 
            this.PB_xiaodeng.Location = new System.Drawing.Point(25, 52);
            this.PB_xiaodeng.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.PB_xiaodeng.Name = "PB_xiaodeng";
            this.PB_xiaodeng.Size = new System.Drawing.Size(299, 196);
            this.PB_xiaodeng.TabIndex = 0;
            this.PB_xiaodeng.TabStop = false;
            // 
            // BTN_red
            // 
            this.BTN_red.Location = new System.Drawing.Point(2, 367);
            this.BTN_red.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.BTN_red.Name = "BTN_red";
            this.BTN_red.Size = new System.Drawing.Size(90, 51);
            this.BTN_red.TabIndex = 8;
            this.BTN_red.Text = "关红灯";
            this.BTN_red.UseVisualStyleBackColor = true;
            this.BTN_red.Click += new System.EventHandler(this.BTN_red_Click);
            // 
            // BTN_green
            // 
            this.BTN_green.Location = new System.Drawing.Point(128, 367);
            this.BTN_green.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.BTN_green.Name = "BTN_green";
            this.BTN_green.Size = new System.Drawing.Size(91, 51);
            this.BTN_green.TabIndex = 9;
            this.BTN_green.Text = "关绿灯";
            this.BTN_green.UseVisualStyleBackColor = true;
            this.BTN_green.Click += new System.EventHandler(this.BTN_green_Click);
            // 
            // BTN_blue
            // 
            this.BTN_blue.Location = new System.Drawing.Point(244, 367);
            this.BTN_blue.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.BTN_blue.Name = "BTN_blue";
            this.BTN_blue.Size = new System.Drawing.Size(80, 51);
            this.BTN_blue.TabIndex = 10;
            this.BTN_blue.Text = "关蓝灯";
            this.BTN_blue.UseVisualStyleBackColor = true;
            this.BTN_blue.Click += new System.EventHandler(this.BTN_blue_Click);
            // 
            // LB_red
            // 
            this.LB_red.Location = new System.Drawing.Point(16, 276);
            this.LB_red.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.LB_red.Name = "LB_red";
            this.LB_red.Size = new System.Drawing.Size(64, 62);
            this.LB_red.TabIndex = 12;
            // 
            // LB_green
            // 
            this.LB_green.Location = new System.Drawing.Point(141, 276);
            this.LB_green.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.LB_green.Name = "LB_green";
            this.LB_green.Size = new System.Drawing.Size(62, 62);
            this.LB_green.TabIndex = 13;
            this.LB_green.Click += new System.EventHandler(this.LB_green_Click);
            // 
            // LB_blue
            // 
            this.LB_blue.Location = new System.Drawing.Point(261, 276);
            this.LB_blue.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.LB_blue.Name = "LB_blue";
            this.LB_blue.Size = new System.Drawing.Size(63, 62);
            this.LB_blue.TabIndex = 14;
            this.LB_blue.Click += new System.EventHandler(this.LB_blue_Click);
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(332, 520);
            this.Controls.Add(this.LB_blue);
            this.Controls.Add(this.LB_green);
            this.Controls.Add(this.LB_red);
            this.Controls.Add(this.BTN_blue);
            this.Controls.Add(this.BTN_green);
            this.Controls.Add(this.BTN_red);
            this.Controls.Add(this.PB_xiaodeng);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.Name = "Form2";
            this.Text = "控制灯亮";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form2_FormClosing);
            this.Load += new System.EventHandler(this.Form2_Load);
            ((System.ComponentModel.ISupportInitialize)(this.PB_xiaodeng)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox PB_xiaodeng;
        private System.Windows.Forms.Button BTN_red;
        private System.Windows.Forms.Button BTN_green;
        private System.Windows.Forms.Button BTN_blue;
        private System.Windows.Forms.Label LB_red;
        private System.Windows.Forms.Label LB_green;
        private System.Windows.Forms.Label LB_blue;
    }
}