﻿namespace iot_ipv6_sever1
{
    partial class Form1
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.TB_port = new System.Windows.Forms.TextBox();
            this.BTN_connect = new System.Windows.Forms.Button();
            this.LB_main = new System.Windows.Forms.ListBox();
            this.BTN_senddata = new System.Windows.Forms.Button();
            this.TB_senddata = new System.Windows.Forms.TextBox();
            this.BTN_port = new System.Windows.Forms.Button();
            this.TB_listen = new System.Windows.Forms.TextBox();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.退出ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.contextMenuStrip2 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.LB_connecting = new System.Windows.Forms.ListBox();
            this.PGB_opensever = new System.Windows.Forms.ProgressBar();
            this.label2 = new System.Windows.Forms.Label();
            this.contextMenuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.label1.Font = new System.Drawing.Font("SimSun", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(42, 257);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(237, 19);
            this.label1.TabIndex = 0;
            this.label1.Text = "物联网节点与网关连接列表";
            // 
            // label3
            // 
            this.label3.Font = new System.Drawing.Font("SimSun", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label3.Location = new System.Drawing.Point(42, 51);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(68, 21);
            this.label3.TabIndex = 3;
            this.label3.Text = "端口号：";
            // 
            // TB_port
            // 
            this.TB_port.Location = new System.Drawing.Point(114, 51);
            this.TB_port.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.TB_port.Name = "TB_port";
            this.TB_port.ReadOnly = true;
            this.TB_port.Size = new System.Drawing.Size(76, 20);
            this.TB_port.TabIndex = 4;
            this.TB_port.Text = "80";
            this.TB_port.TextChanged += new System.EventHandler(this.TB_port_TextChanged);
            // 
            // BTN_connect
            // 
            this.BTN_connect.Location = new System.Drawing.Point(228, 41);
            this.BTN_connect.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.BTN_connect.Name = "BTN_connect";
            this.BTN_connect.Size = new System.Drawing.Size(83, 36);
            this.BTN_connect.TabIndex = 5;
            this.BTN_connect.Text = "启动服务器";
            this.BTN_connect.UseVisualStyleBackColor = true;
            this.BTN_connect.Click += new System.EventHandler(this.BTN_connect_Click);
            // 
            // LB_main
            // 
            this.LB_main.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.LB_main.Font = new System.Drawing.Font("SimSun", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.LB_main.FormattingEnabled = true;
            this.LB_main.ItemHeight = 14;
            this.LB_main.Location = new System.Drawing.Point(390, 103);
            this.LB_main.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.LB_main.Name = "LB_main";
            this.LB_main.Size = new System.Drawing.Size(327, 368);
            this.LB_main.TabIndex = 6;
            // 
            // BTN_senddata
            // 
            this.BTN_senddata.Location = new System.Drawing.Point(254, 510);
            this.BTN_senddata.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.BTN_senddata.Name = "BTN_senddata";
            this.BTN_senddata.Size = new System.Drawing.Size(71, 32);
            this.BTN_senddata.TabIndex = 8;
            this.BTN_senddata.Text = "发送数据";
            this.BTN_senddata.UseVisualStyleBackColor = true;
            this.BTN_senddata.Click += new System.EventHandler(this.BTN_senddata_Click);
            // 
            // TB_senddata
            // 
            this.TB_senddata.Location = new System.Drawing.Point(44, 460);
            this.TB_senddata.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.TB_senddata.Multiline = true;
            this.TB_senddata.Name = "TB_senddata";
            this.TB_senddata.Size = new System.Drawing.Size(282, 28);
            this.TB_senddata.TabIndex = 9;
            // 
            // BTN_port
            // 
            this.BTN_port.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.BTN_port.Location = new System.Drawing.Point(397, 508);
            this.BTN_port.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.BTN_port.Name = "BTN_port";
            this.BTN_port.Size = new System.Drawing.Size(87, 36);
            this.BTN_port.TabIndex = 10;
            this.BTN_port.Text = "清空显示";
            this.BTN_port.UseVisualStyleBackColor = true;
            this.BTN_port.Click += new System.EventHandler(this.BTN_port_Click);
            // 
            // TB_listen
            // 
            this.TB_listen.Location = new System.Drawing.Point(45, 155);
            this.TB_listen.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.TB_listen.Multiline = true;
            this.TB_listen.Name = "TB_listen";
            this.TB_listen.Size = new System.Drawing.Size(170, 66);
            this.TB_listen.TabIndex = 11;
            this.TB_listen.TextChanged += new System.EventHandler(this.TB_listen_TextChanged);
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.退出ToolStripMenuItem});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(101, 26);
            // 
            // 退出ToolStripMenuItem
            // 
            this.退出ToolStripMenuItem.Name = "退出ToolStripMenuItem";
            this.退出ToolStripMenuItem.Size = new System.Drawing.Size(100, 22);
            this.退出ToolStripMenuItem.Text = "退出";
            this.退出ToolStripMenuItem.Click += new System.EventHandler(this.退出ToolStripMenuItem_Click);
            // 
            // contextMenuStrip2
            // 
            this.contextMenuStrip2.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.contextMenuStrip2.Name = "contextMenuStrip2";
            this.contextMenuStrip2.Size = new System.Drawing.Size(61, 4);
            // 
            // LB_connecting
            // 
            this.LB_connecting.Font = new System.Drawing.Font("SimSun", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.LB_connecting.ForeColor = System.Drawing.Color.Red;
            this.LB_connecting.FormattingEnabled = true;
            this.LB_connecting.ItemHeight = 16;
            this.LB_connecting.Location = new System.Drawing.Point(44, 307);
            this.LB_connecting.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.LB_connecting.Name = "LB_connecting";
            this.LB_connecting.Size = new System.Drawing.Size(282, 116);
            this.LB_connecting.TabIndex = 12;
            // 
            // PGB_opensever
            // 
            this.PGB_opensever.Location = new System.Drawing.Point(45, 103);
            this.PGB_opensever.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.PGB_opensever.Name = "PGB_opensever";
            this.PGB_opensever.Size = new System.Drawing.Size(256, 23);
            this.PGB_opensever.TabIndex = 14;
            // 
            // label2
            // 
            this.label2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("SimSun", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(386, 49);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(309, 22);
            this.label2.TabIndex = 16;
            this.label2.Text = "实时异步监听物联网节点消息";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(728, 556);
            this.ContextMenuStrip = this.contextMenuStrip1;
            this.Controls.Add(this.label2);
            this.Controls.Add(this.PGB_opensever);
            this.Controls.Add(this.LB_connecting);
            this.Controls.Add(this.TB_listen);
            this.Controls.Add(this.BTN_port);
            this.Controls.Add(this.TB_senddata);
            this.Controls.Add(this.BTN_senddata);
            this.Controls.Add(this.LB_main);
            this.Controls.Add(this.BTN_connect);
            this.Controls.Add(this.TB_port);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label1);
            this.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.Name = "Form1";
            this.Text = "基于ipv6的物联网服务器平台";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.contextMenuStrip1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox TB_port;
        private System.Windows.Forms.Button BTN_connect;
        public System.Windows.Forms.ListBox LB_main;
        private System.Windows.Forms.Button BTN_senddata;
        private System.Windows.Forms.TextBox TB_senddata;
        private System.Windows.Forms.Button BTN_port;
        private System.Windows.Forms.TextBox TB_listen;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem 退出ToolStripMenuItem;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip2;
        public System.Windows.Forms.ListBox LB_connecting;
        private System.Windows.Forms.ProgressBar PGB_opensever;
        private System.Windows.Forms.Label label2;
    }
}

