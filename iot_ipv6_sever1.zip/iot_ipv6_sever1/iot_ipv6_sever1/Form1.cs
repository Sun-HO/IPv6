﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net.Sockets;
using System.Net;
using System.Threading;

namespace iot_ipv6_sever1
{
   
    

    public partial class Form1 : Form
    {

        public AsyncTCPServer ar;
        public static Form1 f1;
        

        public Form1()
        {
            InitializeComponent();
            CheckForIllegalCrossThreadCalls = false;
            
            f1 = this;
           
            //BackgroundImage = Image.FromFile("..\\..\\image/1.jpg");

        }

        /**
         * 
         * 启动服务器函数
         * 
         */

        private void BTN_connect_Click(object sender, EventArgs e)
        {

            

            if (TB_port.Text.Equals(""))
            {
                MessageBox.Show("端口号不能为空");
            }
            else
            {
                if (BTN_connect.Text == "启动服务器")
                {
                    try
                    {
                        int port = int.Parse(TB_port.Text);
                        ar = new AsyncTCPServer(port);
                        ar.Start(10);
                        PGB_opensever.Value = 80;
                    }
                    catch (SocketException e1)
                    {
                        Console.WriteLine("SocketException: {0}", e1);
                    }

                    

                    LB_main.Items.Add("启动服务器成功，开始监听端口:" + TB_port.Text);
                    BTN_connect.Text = "关闭服务器";
                    PGB_opensever.Value = 100;
                }
                else
                {
                    ar.Stop();
                    LB_main.Items.Add("服务器关闭");
                    BTN_connect.Text = "启动服务器";
                    PGB_opensever.Value = 0;
                }
            }
            
        }

        /**
         * 
         * 窗体读取函数
         * 
         */
    
        private void Form1_Load(object sender, EventArgs e)
        {
            
            //PB_log.Image = Image.FromFile("..\\..\\image/log.png");
            
            
            String ipv4 = Dns.GetHostEntry(Dns.GetHostName()).AddressList.FirstOrDefault<IPAddress>(a => a.AddressFamily.ToString().Equals("InterNetwork")).ToString();
            String ipv6 = Dns.GetHostEntry(Dns.GetHostName()).AddressList.FirstOrDefault<IPAddress>(a => a.AddressFamily.ToString().Equals("InterNetworkV6")).ToString();
            TB_listen.Text += "本机IP地址\r\n";
            TB_listen.Text += "ipv4:"+ipv4+"\r\n";
            TB_listen.Text += "ipv6:"+ipv6+"\r\n";

            
            
            //将label背景颜色设为适应父窗体
            label1.BackColor = Color.Transparent;
            label2.BackColor = Color.Transparent;

        }


        private void BT_stoplisten_Click(object sender, EventArgs e)
        {
            
           
        }

        /**
         * 
         * 发送数据函数
         * 
         */
        private void BTN_senddata_Click(object sender, EventArgs e)
        {
            String data = TB_senddata.Text;
            // 处理客户端发送的数据。
            byte[] msg= System.Text.Encoding.ASCII.GetBytes(data);


            try
            {

                for (int i = 0; i < ar._clients.Count(); i++)
                {
                    IPEndPoint clientipe1 = (IPEndPoint)((TCPClientState)ar._clients[i]).TcpClient.Client.RemoteEndPoint;
                    String a1 = clientipe1.Address.ToString() + ":" + clientipe1.Port.ToString();
                    if (a1.Equals(LB_connecting.SelectedItem.ToString()))
                    {
                        ar.Send((TCPClientState)ar._clients[i], msg);
                        LB_main.Items.Add("向" + clientipe1.Address.ToString() + ":" + clientipe1.Port.ToString() + "发送" + data);
                        // 发回回复。
                    }
                }

            }
            catch
            {

            }

            
            //获取需要发送数据的终点客户端ip地址
            //IPEndPoint clientipe = (IPEndPoint)tls.TcpClient.Client.RemoteEndPoint;

            

        }

        private void BTN_port_Click(object sender, EventArgs e)
        {
            LB_main.Items.Clear();
        }

        private void 退出ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void TB_listen_TextChanged(object sender, EventArgs e)
        {

        }

        

        

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void TB_port_TextChanged(object sender, EventArgs e)
        {

        }
    }
}

    

