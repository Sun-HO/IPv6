﻿namespace iot_ipv6_sever1
{
    partial class FormMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.功能ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.监听物联网节点ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.控制选中节点ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.断开选中节点ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.查看ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.小灯操作记录ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.温湿度记录ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.项目说明ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.基本功能ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.数据库说明ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.版本记录ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.使用帮助ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.使用说明书ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.退出ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.退出ToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.SCT1 = new System.Windows.Forms.SplitContainer();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.SCT1)).BeginInit();
            this.SCT1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.功能ToolStripMenuItem,
            this.查看ToolStripMenuItem,
            this.项目说明ToolStripMenuItem,
            this.使用帮助ToolStripMenuItem,
            this.退出ToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Padding = new System.Windows.Forms.Padding(4, 2, 0, 2);
            this.menuStrip1.Size = new System.Drawing.Size(1020, 24);
            this.menuStrip1.TabIndex = 1;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // 功能ToolStripMenuItem
            // 
            this.功能ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.监听物联网节点ToolStripMenuItem,
            this.控制选中节点ToolStripMenuItem,
            this.断开选中节点ToolStripMenuItem});
            this.功能ToolStripMenuItem.Name = "功能ToolStripMenuItem";
            this.功能ToolStripMenuItem.Size = new System.Drawing.Size(71, 20);
            this.功能ToolStripMenuItem.Text = "实时功能";
            this.功能ToolStripMenuItem.Click += new System.EventHandler(this.功能ToolStripMenuItem_Click);
            // 
            // 监听物联网节点ToolStripMenuItem
            // 
            this.监听物联网节点ToolStripMenuItem.Name = "监听物联网节点ToolStripMenuItem";
            this.监听物联网节点ToolStripMenuItem.Size = new System.Drawing.Size(165, 22);
            this.监听物联网节点ToolStripMenuItem.Text = "监听物联网节点";
            this.监听物联网节点ToolStripMenuItem.Click += new System.EventHandler(this.监听物联网节点ToolStripMenuItem_Click);
            // 
            // 控制选中节点ToolStripMenuItem
            // 
            this.控制选中节点ToolStripMenuItem.Name = "控制选中节点ToolStripMenuItem";
            this.控制选中节点ToolStripMenuItem.Size = new System.Drawing.Size(165, 22);
            this.控制选中节点ToolStripMenuItem.Text = "控制选中节点";
            this.控制选中节点ToolStripMenuItem.Click += new System.EventHandler(this.控制选中节点ToolStripMenuItem_Click);
            // 
            // 断开选中节点ToolStripMenuItem
            // 
            this.断开选中节点ToolStripMenuItem.Name = "断开选中节点ToolStripMenuItem";
            this.断开选中节点ToolStripMenuItem.Size = new System.Drawing.Size(165, 22);
            this.断开选中节点ToolStripMenuItem.Text = "断开选中节点";
            this.断开选中节点ToolStripMenuItem.Click += new System.EventHandler(this.断开选中节点ToolStripMenuItem_Click);
            // 
            // 查看ToolStripMenuItem
            // 
            this.查看ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.小灯操作记录ToolStripMenuItem,
            this.温湿度记录ToolStripMenuItem});
            this.查看ToolStripMenuItem.Name = "查看ToolStripMenuItem";
            this.查看ToolStripMenuItem.Size = new System.Drawing.Size(71, 20);
            this.查看ToolStripMenuItem.Text = "查看历史";
            // 
            // 小灯操作记录ToolStripMenuItem
            // 
            this.小灯操作记录ToolStripMenuItem.Name = "小灯操作记录ToolStripMenuItem";
            this.小灯操作记录ToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.小灯操作记录ToolStripMenuItem.Text = "小灯操作记录";
            this.小灯操作记录ToolStripMenuItem.Click += new System.EventHandler(this.小灯操作记录ToolStripMenuItem_Click);
            // 
            // 温湿度记录ToolStripMenuItem
            // 
            this.温湿度记录ToolStripMenuItem.Name = "温湿度记录ToolStripMenuItem";
            this.温湿度记录ToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.温湿度记录ToolStripMenuItem.Text = "温湿度记录";
            this.温湿度记录ToolStripMenuItem.Click += new System.EventHandler(this.温湿度记录ToolStripMenuItem_Click);
            // 
            // 项目说明ToolStripMenuItem
            // 
            this.项目说明ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.基本功能ToolStripMenuItem,
            this.数据库说明ToolStripMenuItem,
            this.版本记录ToolStripMenuItem});
            this.项目说明ToolStripMenuItem.Name = "项目说明ToolStripMenuItem";
            this.项目说明ToolStripMenuItem.Size = new System.Drawing.Size(71, 20);
            this.项目说明ToolStripMenuItem.Text = "项目说明";
            // 
            // 基本功能ToolStripMenuItem
            // 
            this.基本功能ToolStripMenuItem.Name = "基本功能ToolStripMenuItem";
            this.基本功能ToolStripMenuItem.Size = new System.Drawing.Size(139, 22);
            this.基本功能ToolStripMenuItem.Text = "基本功能";
            this.基本功能ToolStripMenuItem.Click += new System.EventHandler(this.基本功能ToolStripMenuItem_Click);
            // 
            // 数据库说明ToolStripMenuItem
            // 
            this.数据库说明ToolStripMenuItem.Name = "数据库说明ToolStripMenuItem";
            this.数据库说明ToolStripMenuItem.Size = new System.Drawing.Size(139, 22);
            this.数据库说明ToolStripMenuItem.Text = "数据库说明";
            this.数据库说明ToolStripMenuItem.Click += new System.EventHandler(this.数据库说明ToolStripMenuItem_Click);
            // 
            // 版本记录ToolStripMenuItem
            // 
            this.版本记录ToolStripMenuItem.Name = "版本记录ToolStripMenuItem";
            this.版本记录ToolStripMenuItem.Size = new System.Drawing.Size(139, 22);
            this.版本记录ToolStripMenuItem.Text = "版本记录";
            this.版本记录ToolStripMenuItem.Click += new System.EventHandler(this.版本记录ToolStripMenuItem_Click);
            // 
            // 使用帮助ToolStripMenuItem
            // 
            this.使用帮助ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.使用说明书ToolStripMenuItem});
            this.使用帮助ToolStripMenuItem.Name = "使用帮助ToolStripMenuItem";
            this.使用帮助ToolStripMenuItem.Size = new System.Drawing.Size(71, 20);
            this.使用帮助ToolStripMenuItem.Text = "使用帮助";
            // 
            // 使用说明书ToolStripMenuItem
            // 
            this.使用说明书ToolStripMenuItem.Name = "使用说明书ToolStripMenuItem";
            this.使用说明书ToolStripMenuItem.Size = new System.Drawing.Size(139, 22);
            this.使用说明书ToolStripMenuItem.Text = "使用说明书";
            this.使用说明书ToolStripMenuItem.Click += new System.EventHandler(this.使用说明书ToolStripMenuItem_Click);
            // 
            // 退出ToolStripMenuItem
            // 
            this.退出ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.退出ToolStripMenuItem1});
            this.退出ToolStripMenuItem.Name = "退出ToolStripMenuItem";
            this.退出ToolStripMenuItem.Size = new System.Drawing.Size(45, 20);
            this.退出ToolStripMenuItem.Text = "退出";
            // 
            // 退出ToolStripMenuItem1
            // 
            this.退出ToolStripMenuItem1.Name = "退出ToolStripMenuItem1";
            this.退出ToolStripMenuItem1.Size = new System.Drawing.Size(100, 22);
            this.退出ToolStripMenuItem1.Text = "退出";
            // 
            // SCT1
            // 
            this.SCT1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.SCT1.Location = new System.Drawing.Point(0, 24);
            this.SCT1.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.SCT1.Name = "SCT1";
            // 
            // SCT1.Panel1
            // 
            this.SCT1.Panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.SCT1_Panel1_Paint);
            this.SCT1.Size = new System.Drawing.Size(1020, 618);
            this.SCT1.SplitterDistance = 697;
            this.SCT1.SplitterWidth = 3;
            this.SCT1.TabIndex = 3;
            // 
            // FormMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1020, 642);
            this.Controls.Add(this.SCT1);
            this.Controls.Add(this.menuStrip1);
            this.IsMdiContainer = true;
            this.MainMenuStrip = this.menuStrip1;
            this.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.Name = "FormMain";
            this.Text = "基于ipv6的物联网服务器平台";
            this.Load += new System.EventHandler(this.FormMain_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.SCT1)).EndInit();
            this.SCT1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem 功能ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 监听物联网节点ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 控制选中节点ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 查看ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 项目说明ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 使用帮助ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 退出ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 断开选中节点ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 小灯操作记录ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 温湿度记录ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 退出ToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem 基本功能ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 数据库说明ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 版本记录ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 使用说明书ToolStripMenuItem;
        public System.Windows.Forms.SplitContainer SCT1;
    }
}