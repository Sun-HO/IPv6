﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace iot_ipv6_sever1
{
    public partial class Form2 : Form
    {
        TCPClientState tcs = null;
        sqlDao sd = new sqlDao();


        public Form2()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {

            String state = Form1.f1.LB_connecting.SelectedItem.ToString();
            PB_xiaodeng.Image = Image.FromFile("..\\..\\image/xiaodeng.jpg");

            LB_red.BackColor = Color.Red;
            LB_green.BackColor = Color.Yellow;
            LB_blue.BackColor = Color.Blue;

            //获取当前连接状态
            for (int i = 0; i < Form1.f1.ar._clients.Count(); i++)
            {
                IPEndPoint clientipe = (IPEndPoint)((TCPClientState)Form1.f1.ar._clients[i]).TcpClient.Client.RemoteEndPoint;
                String a1 = clientipe.Address.ToString() + ":" + clientipe.Port.ToString();
                if (a1.Equals(state))
                {
                    tcs= (TCPClientState)Form1.f1.ar._clients[i];
                }
            }
        }
        private void LB_connectedport_Click(object sender, EventArgs e)
        {

        }
        /**
         * 
         * 
         */
        private void BTN_red_Click(object sender, EventArgs e)
        {
            if (BTN_red.Text == "开红灯")
            {
                LB_red.BackColor = Color.Red;
                BTN_red.Text = "关红灯";
                DateTime.Now.ToString();


                //向当前连接节点发送开灯指令
                byte[] msg = Encoding.ASCII.GetBytes("OB");
                Form1.f1.ar.Send(tcs,msg);
                Form1.f1.LB_main.Items.Add(DateTime.Now.ToString()+"时红灯亮");
                
                sd.insertDataA("红灯亮");

            }
            else
            {
                LB_red.BackColor = Color.Transparent;
                BTN_red.Text = "开红灯";
                //向当前连接节点发送开灯指令
                byte[] msg = Encoding.ASCII.GetBytes("CB");
                Form1.f1.ar.Send(tcs, msg);
                Form1.f1.LB_main.Items.Add(DateTime.Now.ToString() + "时红灯灭");
                sd.insertDataA("红灯灭");
            }
        }

        private void BTN_green_Click(object sender, EventArgs e)
        {
            if (BTN_green.Text == "开黄灯")
            {
                //向当前连接节点发送开灯指令
                byte[] msg = Encoding.ASCII.GetBytes("OG");
                Form1.f1.ar.Send(tcs, msg);

                LB_green.BackColor = Color.Yellow;
                BTN_green.Text = "关黄灯";
                Form1.f1.LB_main.Items.Add(DateTime.Now.ToString() + "时绿灯亮");
                sd.insertDataA("黄灯亮");
            }
            else
            {
                //向当前连接节点发送开灯指令
                byte[] msg = Encoding.ASCII.GetBytes("CG");
                Form1.f1.ar.Send(tcs, msg);
                LB_green.BackColor = Color.Transparent;
                BTN_green.Text = "开黄灯";
                Form1.f1.LB_main.Items.Add(DateTime.Now.ToString() + "时绿灯灭");
                sd.insertDataA("黄灯灭");
            }
        }

        private void BTN_blue_Click(object sender, EventArgs e)
        {
            if (BTN_blue.Text == "开蓝灯")
            {
                //向当前连接节点发送开灯指令
                byte[] msg = Encoding.ASCII.GetBytes("OR");
                Form1.f1.ar.Send(tcs, msg);
                LB_blue.BackColor = Color.Blue;
                BTN_blue.Text = "关蓝灯";
                Form1.f1.LB_main.Items.Add(DateTime.Now.ToString() + "时蓝灯亮");
                sd.insertDataA("蓝灯亮");
            }
            else
            {
                //向当前连接节点发送开灯指令
                byte[] msg = Encoding.ASCII.GetBytes("CR");
                Form1.f1.ar.Send(tcs, msg);
                LB_blue.BackColor = Color.Transparent;
                BTN_blue.Text = "开蓝灯";
                Form1.f1.LB_main.Items.Add(DateTime.Now.ToString() + "时蓝灯灭");
                sd.insertDataA("蓝灯灭");
            }
        }

        private void LB_green_Click(object sender, EventArgs e)
        {

        }

        private void Form2_FormClosing(object sender, FormClosingEventArgs e)
        {
            FormMain.fm.SCT1.Panel2Collapsed = true;
        }

        private void LB_blue_Click(object sender, EventArgs e)
        {

        }
    }
}
