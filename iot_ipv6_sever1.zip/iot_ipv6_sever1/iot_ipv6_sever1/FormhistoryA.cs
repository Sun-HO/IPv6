﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace iot_ipv6_sever1
{
    public partial class FormhistoryA : Form
    {

        
        public FormhistoryA()
        {
            InitializeComponent();
            
        }

        private void FormhistoryA_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            String year=dateTimePicker1.Value.Year.ToString();
            String month = dateTimePicker1.Value.Month.ToString();
            String day = dateTimePicker1.Value.Day.ToString();
            String date = year + "/" + month + "/" + day;
           
            sqlDao sd = new sqlDao();
            sd.searchDataA(date,this);

        }

        private void FormhistoryA_FormClosing(object sender, FormClosingEventArgs e)
        {
            FormMain.fm.SCT1.Panel2Collapsed = true;
        }
    }
}
