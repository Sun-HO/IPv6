﻿
using System;

using System.Collections.Generic;

using System.Linq;

using System.Text;

using System.Threading.Tasks;

using System.Data.SqlClient;


namespace iot_ipv6_sever1
{
     class sqlDao 
    {
        //数据库连接字符串，注意这个写法（localdb）后面必须是两个斜杠，因为这中间有个转义的过程

        //Initial Catalog=要连接的数据库名

        //Intergrated Security=true  开启windows身份验证

        string ConnectString = "Server=(localdb)\\ProjectsV13;Initial Catalog=test;Integrated Security=true";

        SqlConnection con = null;

        SqlCommand cmd = null;

        SqlDataReader str = null;

        /**
         * 构造方法
         * 打开数据连接函数
         * 
         */
        public sqlDao()
        {
            try
            {
                con = new SqlConnection(ConnectString);       //连接到数据库
                con.Open();   //创建连接后需要用Open打开连接，结束后要关闭连接，及时释放资源
            }
            catch (Exception ms)

            {
                 Console.WriteLine(ms.Message);
            }
        }

        /**
         *向小灯数据表中插入数据 
         * 
         */
         public int insertDataA(String action)
        {
            try
            {
                //获取当前系统的时间
                String date1 = DateTime.Now.ToShortDateString();
                String[] a1 = date1.Split('/');
                String date = a1[2] + "/" + a1[0] + "/" + a1[1];
                String time = DateTime.Now.ToString();
                String sqlstr = "INSERT INTO [dbo].[log]([date],[time],[action]) VALUES('"+ date + "','"+time+"',N'"+action+"')";      
                cmd = new SqlCommand(sqlstr, con);

                int result = cmd.ExecuteNonQuery();

                if (result == 1)
                {
                    //Console.WriteLine("插入成功");
                    
                }
            }
            catch (Exception ms)

            {
                Console.WriteLine(ms.Message);
                return 0;
            }

            return 1;
        }
        /**
         *向温度湿度数据表中插入数据 
         * 
         */
        public int insertDataB(String state)
        {
            try
            {
                //获取当前系统的时间
                String date1 = DateTime.Now.ToShortDateString();
                String[] a1 = date1.Split('/');
                String date = a1[2] + "/" + a1[0] + "/" + a1[1];
                String time = DateTime.Now.ToString();
                String sqlstr = "INSERT INTO [dbo].[wsd]([date],[time],[state]) VALUES('" + date + "','" + time + "','" + state + "')";
                cmd = new SqlCommand(sqlstr, con);

                int result = cmd.ExecuteNonQuery();

                if (result == 1)
                {
                    Console.WriteLine("插入成功");

                }
            }
            catch (Exception ms)

            {
                Console.WriteLine(ms.Message);
                return 0;
            }

            return 1;
        }

        /**
        *  查询小灯操作的历史日志 
        * 
        */
        public void searchDataA(String date, FormhistoryA fha)
        {
            try
            {

                String sqlstr = "select * from dbo.log where date ='"+ date + "'";
                cmd = new SqlCommand(sqlstr, con);

                str = cmd.ExecuteReader();
                while (str.Read())
                {

                    //Console.WriteLine(str["date"].ToString());
                    //String sss = str["time"].ToString();
                    //Form1.f1.LB_main.Items.Add(str["time"].ToString());
                    fha.listBox1.Items.Add(str["time"].ToString()+" 时"+ str["action"].ToString());
                    
                }

            }

            catch (Exception ms)

            {

                Console.WriteLine(ms.Message);

            }
            
        }
        /**
       *  查询温度湿度的历史日志 
       * 
       */
        public void searchDataB(String date, FormhistoryB fhb)
        {
            try
            {

                String sqlstr = "select * from dbo.wsd where date ='" + date + "'";
                cmd = new SqlCommand(sqlstr, con);

                str = cmd.ExecuteReader();
                while (str.Read())
                {

                    //Console.WriteLine(str["date"].ToString());
                    if (str["state"].ToString().Contains("T"))
                    {
                        fhb.LB_history.Items.Add("在" + str["time"].ToString() + "时温度为" + str["state"].ToString());

                    }
                    else
                    {
                        fhb.LB_history.Items.Add("在" + str["time"].ToString() + "时湿度为" + str["state"].ToString());
                    }
                    
                    

                }

            }

            catch (Exception ms)

            {

                Console.WriteLine(ms.Message);

            }

        }
    }
}
