﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace iot_ipv6_sever1
{
    public partial class FormMain : Form
    {

        public static FormMain fm;

        public static Form2 f2;

        public FormMain()
        {
            InitializeComponent();
            fm = this;
        }

        private void 监听物联网节点ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
            Form1 f1 = new Form1();
            f1.TopLevel = false;
            SCT1.Panel1.Controls.Add(f1);
            f1.Show();
            f1.Dock = DockStyle.Fill;
        }

        private void 控制选中节点ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if(f2!=null)f2.Close();
            SCT1.Panel2Collapsed = false;
             f2 = new Form2();
            f2.TopLevel = false;
            SCT1.Panel2.Controls.Add(f2);
            f2.Show();
            f2.Dock = DockStyle.Fill;
        }

        private void 断开选中节点ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {

                for (int i = 0; i < Form1.f1.ar._clients.Count(); i++)
                {
                    IPEndPoint clientipe = (IPEndPoint)((TCPClientState)Form1.f1.ar._clients[i]).TcpClient.Client.RemoteEndPoint;
                    String a1 = clientipe.Address.ToString() + ":" + clientipe.Port.ToString();
                    if (a1.Equals(Form1.f1.LB_connecting.SelectedItem.ToString()))
                    {
                        Form1.f1.ar.Close(((TCPClientState)Form1.f1.ar._clients[i]));

                    }
                }
            }
            catch
            {
            }
            Form1.f1.LB_connecting.Items.Remove(Form1.f1.LB_connecting.SelectedItem);
        }

        private void 功能ToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void 小灯操作记录ToolStripMenuItem_Click(object sender, EventArgs e)
        {
          
            SCT1.Panel2Collapsed = false;
            FormhistoryA fA = new FormhistoryA();
            fA.TopLevel = false;
            SCT1.Panel2.Controls.Add(fA);
            fA.Show();
            fA.Dock = DockStyle.Fill;
        }

        private void FormMain_Load(object sender, EventArgs e)
        {
            SCT1.Panel2Collapsed = true;
        }

        private void 温湿度记录ToolStripMenuItem_Click(object sender, EventArgs e)
        {
           

            SCT1.Panel2Collapsed = false;
            FormhistoryB fB = new FormhistoryB();
            fB.TopLevel = false;
            SCT1.Panel2.Controls.Add(fB);
            fB.Show();
            fB.Dock = DockStyle.Fill;
        }

        private void SCT1_Panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void 基本功能ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("基于ipv6的物联网服务器平台V3.0基本功能\r\n1.实时异步监听物联网节点\r\n2.实时控制小灯节点灯开关。\r\n3.小灯操作记录与温湿度传感器数据存入数据库\r\n4.查看小灯操作历史记录与传感器数据历史记录。");
        }

        private void 版本记录ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("基于ipv6的物联网服务器平台版本历史记录\r\nv1.0\r\n1.第一代为C#控制台程序\r\n2.成功与基于ipv6的物联网网关通信成功\r\n3.与物联网网关进行数据的收发\r\n4.不支持异步监听。\r\n\r\n\r\nv2.0\r\n1.将C#控制台程序转变为C#windows桌面程序，从cmd指定操作改进为图形化操作界面。\r\n2.完美适配V1.0版本所有功能\r\n3.支持异步监听，但接收节点数据显示时存在一些bug。\r\n\r\n\r\nv3.0\r\n1.美化桌面程序界面布局\r\n2.支持异步监听，修复已知bug。\r\n3.添加数据库支持，节点数据可以存入数据库，桌面程序也可以查询节点历史记录。");
        }

        private void 数据库说明ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("数据库设计\r\n简介：以日志的形式记录节点信息。\r\n记录小灯操作：表名为dbo.log\r\n列名：id：唯一主键，自动增长\r\ndate：年月日，为查询记录的基础\r\ntime：操作的具体时间\r\naction：记录开关等动作\r\n\r\n记录温湿度状态：表名为dbo.wsd\r\n列名：id：唯一主键，自动增长\r\ndate：年月日，为查询记录的基础\r\ntime：操作的具体时间\r\nstate：记录温度湿度状态");


        }

        private void 使用说明书ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("1.监测物联网节点点击菜单栏的实时功能的第一个。\r\n2.填写端口号后点击启动服务器开始监听。\r\n3.选中节点列表中的节点选择菜单栏实时功能下第二项实时控制节点。\r\n4.点击查看历史下的两项分别查看小灯节点操作历史与温湿度数据历史。\r\n5.菜单栏项目说明下查看系统基本功能，数据库说明和版本记录。");
        }
    }
}
