/*
 * Copyright (c) 2013, Thingsquare, http://www.thingsquare.com/.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 */

#include "contiki.h"                //contiki系统api库           
#include "contiki-net.h"            //contiki网络api库
#include "contiki-lib.h"            //contiki系统lib库
#include "lib/random.h"             //随机数生成库
#include "sys/ctimer.h"             //系统回调定时器库
#include "sys/etimer.h"             //系统事件定时器库
#include "net/rpl/rpl.h"            //路由相关api
#include "net/ip/uip.h"             //uip协议api
#include "net/ipv6/uip-ds6.h"       //ipv6相关api
#include "dev/leds.h"               //LED驱动库

#include "aes.h"                    //aes库
#include "ip64-addr.h"              //ip64地址
#include "apps/mdns/mdns.h"         //mdns相关
#include "simple-rpl.h"             //rpl相关
#include "tcp-socket.h"             //tcp通信api
#include "udp-socket.h"             //udp通信api

//DHT11
#include <stdlib.h>                         //标准的系统相关接口
#include <stdio.h>                          //标准设备的输入输出相关接口
#include <string.h>                         //字符串处理库
#include "dev/DHT11-arch.h"                 //温湿度传感器dht11接口


//通信端口定义
#define PORT 8088
//tcp socket 数据结构体
static struct tcp_socket socket;
//输入缓冲区为400个字节
#define INPUTBUFSIZE 400
static uint8_t inputbuf[INPUTBUFSIZE];
//输出缓冲区为400个字节
#define OUTPUTBUFSIZE 400
//定义输出缓冲区
static uint8_t outputbuf[OUTPUTBUFSIZE];

static struct etimer timer;
//声明tcp_client_process进程
PROCESS(tcp_client_process, "TCP client example process");
//系统初始化的时候自动启动tcp_client进程
AUTOSTART_PROCESSES(&tcp_client_process);
/*---------------------------------------------------------------------------*/
//输入处理函数
static int
input(struct tcp_socket *s, void *ptr,
      const uint8_t *inputptr, int inputdatalen)
{
	if(inputptr[0]=='C')
		{  
			switch(inputptr[1])
		   {     
			case 'R': leds_on(LEDS_RED);
			break;
			case 'B': leds_on(LEDS_BLUE);
			break;
			case 'Y': leds_on(LEDS_YELLOW);
			break;
			case 'G': leds_on(LEDS_GREEN);
			break;
		  }
		}
	else if(inputptr[0]=='O')

		{   
			switch(inputptr[1])
		   {
			case 'R': leds_off(LEDS_RED);
			break;
			case 'B': leds_off(LEDS_BLUE);
			break;
			case 'Y': leds_off(LEDS_YELLOW);
			break;
			case 'G': leds_off(LEDS_GREEN);
			break;
      		   }
		}
  printf("input %d bytes '%s'\n", inputdatalen, inputptr);
 // tcp_socket_close(s);
  return 0;
}
/*---------------------------------------------------------------------------*/
//事件函数
static void
event(struct tcp_socket *s, void *ptr,
      tcp_socket_event_t ev)
{
  if(ev == TCP_SOCKET_CONNECTED) {
    printf("Socket connected\n");
    tcp_socket_send_str(s, "Connected\n");
  } else if(ev == TCP_SOCKET_DATA_SENT) {
    printf("Socket data was sent\n");
  } else if(ev == TCP_SOCKET_CLOSED) {
    printf("Socket closed\n");
  } else if(ev == TCP_SOCKET_ABORTED) {
    printf("Socket reset\n");
process_start(&tcp_client_process,NULL);
  } else if(ev == TCP_SOCKET_TIMEDOUT) {
    printf("Socket timedout\n");
  }
}
/*---------------------------------------------------------------------------*/
//tcp client进程实现
PROCESS_THREAD(tcp_client_process, ev, data)
{
  //定义ip6addr变量保存ipv6地址
  uip_ip6addr_t ip6addr;
  //定义ip4addr保存ipv4地址
  uip_ip4addr_t ip4addr;
  //进程开始
  PROCESS_BEGIN();

   
  //uip_ipaddr(&ip4addr, 192,168,18,33);
  //ip64_addr_4to6(&ip4addr, &ip6addr);
  //设置ipv6地址
uip_ip6addr(&ip6addr, 0x2409,0x8921,0x5a60,0x642e,0x1223,0x45ff,0xfe67,0x89ab);


// uip_ip6addr(&ip6addr, 0x2409,0x8921,0x5a50,0x2677,0xe829,0xa471,0xc55b,0xf112);
  //tcp socket 通信注册
  tcp_socket_register(&socket, NULL,
                      inputbuf, sizeof(inputbuf),
                      outputbuf, sizeof(outputbuf),
                      input, event);
  //tcp socket连接服务器
  tcp_socket_connect(&socket, &ip6addr, PORT);
clock_delay_usec(100000);
tcp_socket_send(&socket,"#2", 2);
  while(1) {
   etimer_set(&timer, 5 * CLOCK_SECOND);

    //等待事件发生
   PROCESS_WAIT_EVENT_UNTIL(ev==PROCESS_EVENT_TIMER);
 unsigned char  temp[7]="Tem:", humidity[7]="Hun:";
DHT11_Inint();
    //temp="Tem:";
    temp[4] = Tem_dec+0x30;
	  temp[5] = Tem_uni+0x30; 
	  temp[6] = '\0';
        //humidity="Hum:";
	  humidity[4] = Hum_dec+0x30;
	  humidity[5] = Hum_uni+0x30;
	  humidity[6] = '\0';

 tcp_socket_send(&socket,temp, 7);

   tcp_socket_send(&socket,humidity, 7);
  }
  //进程结束
  PROCESS_END();
}
/*---------------------------------------------------------------------------*/
